using System;
using System.Collections.Generic;

namespace Buttr.Core {
    internal sealed class TransientResolverInternal<TConcrete> : ObjectResolverBase<TConcrete> {
        private readonly Dictionary<Type, IObjectResolver> m_Registry;
        private readonly Func<TConcrete, TConcrete> m_Configuration;
        private readonly Func<TConcrete> m_FactoryOverride;

        public TransientResolverInternal(Dictionary<Type, IObjectResolver> registry, Func<TConcrete, TConcrete> configuration, Func<TConcrete> factoryOverride) {
            m_Registry = registry;
            m_Configuration = configuration;
            m_FactoryOverride = factoryOverride;
        }

        public override object Resolve() {
            (var dependencies, var remaining) = m_Registry.GetDependencies(requirements);
            dependencies.AddRange(StaticServiceResolver.GetDependencies(remaining));
            var dArray = dependencies.ToArray();
            
            if (dArray.TryValidate(requirements) == false) {
                throw new ObjectResolverException($"Unable to locate all dependencies for {typeof(TConcrete)}) \r\n Required Dependencies :: {string.Join(", ", requirements)}");
            }

            return m_Configuration(m_FactoryOverride == null
                ? factory(dArray)
                : m_FactoryOverride());
        }
    }
}