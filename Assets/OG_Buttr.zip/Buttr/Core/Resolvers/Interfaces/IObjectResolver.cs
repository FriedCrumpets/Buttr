namespace Buttr.Core {
    internal interface IObjectResolver {
        object Resolve();
    }
}