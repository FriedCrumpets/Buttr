using System;

namespace Buttr.Core {
    internal sealed class ScopeResolver<TScopeDefinition> : IResolver, IConfigurable<IDIBuilder> where TScopeDefinition : IScopeDefinition {
        private Func<IDIBuilder, IDIBuilder> m_Configuration = ConfigurationFactory.Empty<IDIBuilder>();
        private Func<IDIBuilder> m_Factory;
        
        public void Resolve() {
            var builder = m_Factory == null ? new DIBuilder() : m_Factory();
            builder = m_Configuration(builder);
            Scope<TScopeDefinition>.Set(builder);
        }

        public void Dispose() {
            Scope<TScopeDefinition>.Set(null);
        }
        
        IConfigurable<IDIBuilder> IConfigurable<IDIBuilder>.WithConfiguration(Func<IDIBuilder, IDIBuilder> configuration) {
            m_Configuration = configuration;
            return this;
        }
        
        IConfigurable<IDIBuilder> IConfigurable<IDIBuilder>.WithFactory(Func<IDIBuilder> factory) {
            m_Factory = factory;
            return this;
        }
    }
}