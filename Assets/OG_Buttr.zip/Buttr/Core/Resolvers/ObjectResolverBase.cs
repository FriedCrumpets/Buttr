using System;
using System.Collections.Generic;
using System.Linq;

namespace Buttr.Core {
    public abstract class ObjectResolverBase<TConcrete> : IObjectResolver {
        protected readonly List<Type> requirements = new();
        protected readonly Func<object[], TConcrete> factory;

        protected ObjectResolverBase() {
            var constructor = typeof(TConcrete).GetConstructors().FirstOrDefault();
            
            if (constructor == null)
                throw new InvalidOperationException($"No public constructor found for type {typeof(TConcrete)}");

            foreach (var parameter in constructor.GetParameters()) {
                requirements.Add(parameter.ParameterType);
            }

            factory = ObjectFactory.Create<TConcrete>(constructor);
        }

        public abstract object Resolve();
    }
}