using System;

namespace Buttr.Core {
    internal sealed class StaticServiceSingletonResolver<TAbstract, TConcrete> : IResolver, IConfigurable<TConcrete> where TAbstract : IService {
        private Func<TConcrete, TConcrete> m_Configuration = ConfigurationFactory.Empty<TConcrete>();
        private Func<TConcrete> m_Factory;

        private Singleton<TAbstract, TConcrete> m_Singleton;
        
        public void Resolve() {
            m_Singleton = new Singleton<TAbstract, TConcrete>(m_Configuration, m_Factory);
            Service<TAbstract>.Set(m_Singleton);
        }
        
        public void Dispose() {
            if (Service<TAbstract>.Get() is IDisposable disposable) {
                disposable.Dispose();
            }
            
            Service<TAbstract>.Set(null);
            m_Singleton.Dispose(); 
        }
        
        IConfigurable<TConcrete> IConfigurable<TConcrete>.WithConfiguration(Func<TConcrete, TConcrete> configuration) {
            m_Configuration = configuration;
            return this;
        }       
        
        IConfigurable<TConcrete> IConfigurable<TConcrete>.WithFactory(Func<TConcrete> factory) {
            m_Factory = factory;
            return this;
        }
    }
}