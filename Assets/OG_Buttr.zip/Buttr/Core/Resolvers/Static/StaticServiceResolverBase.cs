using System;
using System.Collections.Generic;
using System.Linq;

namespace Buttr.Core {
    internal abstract class StaticServiceResolverBase<TAbstract, TConcrete> : IObjectResolver, IDisposable {
        protected readonly List<Type> requirements = new();
        protected readonly Func<object[], TConcrete> factory;
        
        private readonly IDisposable m_Registration;

        protected StaticServiceResolverBase() {
            var constructor = typeof(TConcrete).GetConstructors().FirstOrDefault();
            
            if (constructor == null)
                throw new InvalidOperationException($"No public constructor found for type {typeof(TConcrete)}");

            foreach (var parameter in constructor.GetParameters()) {
                requirements.Add(parameter.ParameterType);
            }

            factory = ObjectFactory.Create<TConcrete>(constructor);
            m_Registration = StaticServiceResolver.Register<TAbstract>(this);
        }

        public abstract object Resolve();
        
        public void Dispose() {
            m_Registration?.Dispose();
        }
    }
}