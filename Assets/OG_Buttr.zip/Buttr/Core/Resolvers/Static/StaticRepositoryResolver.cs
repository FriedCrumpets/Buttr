using System;

namespace Buttr.Core {
    internal sealed class StaticRepositoryResolver<TAbstract, TConcrete> : IResolver, IConfigurable<TConcrete> {
        private Func<TConcrete, TConcrete> m_Configuration = ConfigurationFactory.Empty<TConcrete>();
        private Func<TConcrete> m_Factory;
        private Singleton<TAbstract,TConcrete> m_Singleton;

        public void Resolve() {
            m_Singleton = new Singleton<TAbstract, TConcrete>(m_Configuration, m_Factory);
        }

        public void Dispose() {
            if (m_Singleton.Resolve() is IDisposable disposable) {
                disposable.Dispose();
            }
            
            m_Singleton.Dispose();
            m_Singleton = null;
        }
        
        IConfigurable<TConcrete> IConfigurable<TConcrete>.WithConfiguration(Func<TConcrete, TConcrete> configuration) {
            m_Configuration = configuration;
            return this;
        }
        
        IConfigurable<TConcrete> IConfigurable<TConcrete>.WithFactory(Func<TConcrete> factory) {
            m_Factory = factory;
            return this;
        }
    }
}