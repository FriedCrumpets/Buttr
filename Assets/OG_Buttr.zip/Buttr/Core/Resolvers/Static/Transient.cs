using System;

namespace Buttr.Core {
    internal sealed class Transient<TAbstract, TConcrete> : StaticServiceResolverBase<TAbstract, TConcrete> {
        private readonly Func<TConcrete, TConcrete> m_Configuration;
        private readonly Func<TConcrete> m_FactoryOverride;

        internal Transient(Func<TConcrete, TConcrete> configuration, Func<TConcrete> factoryOverride) {
            m_Configuration = configuration;
            m_FactoryOverride = factoryOverride;
        }

        public override object Resolve() {
            var dependencies = StaticServiceResolver.GetDependencies(requirements);
            if (dependencies.TryValidate(requirements) == false) {
                throw new ObjectResolverException($"Unable to locate all dependencies for {typeof(TConcrete)}) \r\n Required Dependencies :: {string.Join(", ", requirements)}");
            }
            
            return m_Configuration(m_FactoryOverride == null 
                ? factory(dependencies) 
                : m_FactoryOverride());
        }
    }
}