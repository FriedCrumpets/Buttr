using System;
using System.Collections.Generic;

namespace Buttr.Core {
    internal static class StaticServiceResolver {
        private static readonly Dictionary<Type, IObjectResolver> s_Services;

        static StaticServiceResolver() => s_Services = new();

        public static object[] GetDependencies(List<Type> requirements) {
            var dependencies = new List<object>();

            foreach (var type in requirements) {
                if (s_Services.TryGetValue(type, out var value))
                    dependencies.Add(value.Resolve());
            }
            
            return dependencies.ToArray();
        }

        public static IDisposable Register<T>(IObjectResolver resolver) {
            return new Registration(typeof(T), resolver);
        }

        private sealed class Registration : IDisposable {
            private readonly Type m_Type;
            private IObjectResolver m_Resolver;
            
            public Registration(Type type, IObjectResolver resolver) {
                m_Type = type;
                if (s_Services.TryAdd(type, resolver) == false) {
                    throw new ObjectResolverException($"Failed to add resolver to services, Has {type.Name} already been added?");
                }
            }
            
            public void Dispose() {
                s_Services.Remove(m_Type);
            }
        }
    }
}