using System;

namespace Buttr.Core {
    internal sealed class ContainerResolver<TContainerDefinition> : IResolver, IConfigurable<IDIBuilder> where TContainerDefinition : IContainerDefinition {
        private Func<IDIBuilder, IDIBuilder> m_Configuration = ConfigurationFactory.Empty<IDIBuilder>();
        private Func<IDIBuilder> m_Factory;

        public void Resolve() {
            var builder = m_Factory == null ? new DIBuilder() : m_Factory();
            builder = m_Configuration(builder);
            Container<TContainerDefinition>.Set(builder);
        }
        
        public void Dispose() { 
            Container<TContainerDefinition>.Get().Dispose();
            Container<TContainerDefinition>.Set(null);
        }
        
        IConfigurable<IDIBuilder> IConfigurable<IDIBuilder>.WithConfiguration(Func<IDIBuilder, IDIBuilder> configuration) {
            m_Configuration = configuration;
            return this;
        }
        
        IConfigurable<IDIBuilder> IConfigurable<IDIBuilder>.WithFactory(Func<IDIBuilder> factory) {
            m_Factory = factory;
            return this;
        }
    }
}