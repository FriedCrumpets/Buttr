using System;

namespace Buttr.Core {
    internal sealed class Singleton<TAbstract, TConcrete> : StaticServiceResolverBase<TAbstract, TConcrete>, IObjectResolver {
        private object m_Concrete;
        private readonly Func<TConcrete, TConcrete> m_Configuration;
        private readonly Func<TConcrete> m_FactoryOverride;

        internal Singleton(Func<TConcrete, TConcrete> configuration, Func<TConcrete> factoryOverride) {
            m_Configuration = configuration;
            m_FactoryOverride = factoryOverride;
        }

        public override object Resolve() {
            if (null != m_Concrete) return m_Concrete;
            
            var dependencies = StaticServiceResolver.GetDependencies(requirements);
            if (dependencies.TryValidate(requirements) == false) {
                throw new ObjectResolverException($"Unable to locate all dependencies for {typeof(TConcrete)}) \r\n Required Dependencies :: {string.Join(", ", requirements)}");
            }
            
            m_Concrete = m_Configuration(m_FactoryOverride == null 
                ? factory(dependencies) 
                : m_FactoryOverride());

            return m_Concrete;
        }
    }
}