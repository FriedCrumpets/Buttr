using System;

namespace Buttr.Core {
    internal sealed class IDSingletonResolverInternal<TConcrete> : ObjectResolverBase<TConcrete> {
        private readonly Func<TConcrete, TConcrete> m_Configuration;
        private readonly Func<TConcrete> m_FactoryOverride;

        private TConcrete m_Instance;
        
        public IDSingletonResolverInternal(Func<TConcrete, TConcrete> configuration, Func<TConcrete> factoryOverride) {
            m_Configuration = configuration;
            m_FactoryOverride = factoryOverride;
        }

        public override object Resolve() {
            if (m_Instance != null) return m_Instance;
            
            var dependencies = StaticServiceResolver.GetDependencies(requirements);
            if (dependencies.TryValidate(requirements) == false) {
                throw new ObjectResolverException($"Unable to locate all dependencies for {typeof(TConcrete)}) \r\n Required Dependencies :: {string.Join(", ", requirements)}");
            }

            m_Instance = m_Configuration(m_FactoryOverride == null
                ? factory(dependencies)
                : m_FactoryOverride());

            return m_Instance;
        }
    }
}