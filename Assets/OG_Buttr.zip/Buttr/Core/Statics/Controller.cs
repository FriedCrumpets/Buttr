// ReSharper disable StaticMemberInGenericType

namespace Buttr.Core {
    public static class Controller<T> where T : IController {
        private static IObjectResolver s_ControllerResolver;
        internal static void Set(IObjectResolver serviceResolver) => s_ControllerResolver = serviceResolver;
        public static T Get() => (T)s_ControllerResolver.Resolve();
    }
}