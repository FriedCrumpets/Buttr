// ReSharper disable StaticMemberInGenericType

namespace Buttr.Core {
    public static class Container<TContainerDefinition> where TContainerDefinition : IContainerDefinition {
        private static IDIContainer m_Container;

        internal static void Set(IDIBuilder builder) => m_Container = builder.Build();
        internal static IDIContainer Get() => m_Container;

        public static TAbstract Get<TAbstract>() => m_Container.Get<TAbstract>();
    }
}