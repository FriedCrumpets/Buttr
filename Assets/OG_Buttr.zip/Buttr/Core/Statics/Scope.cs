// ReSharper disable StaticMemberInGenericType

namespace Buttr.Core {
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="TDefinition">
    /// This is a Tag definition, allowing us to separate application scopes.
    /// An empty class or empty interface would be sufficient
    /// </typeparam>
    public static class Scope<TDefinition> where TDefinition : IScopeDefinition {
        private static IDIBuilder m_Builder;

        internal static void Set(IDIBuilder builder) => m_Builder = builder;
        
        public static IScopeBuilder BeginScope() {
            return new ScopeBuilder(m_Builder);
        }
    }
}