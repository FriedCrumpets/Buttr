// ReSharper disable StaticMemberInGenericType

namespace Buttr.Core {
    public static class Configuration<T> where T : IConfiguration {
        private static IObjectResolver s_ControllerResolver;
        internal static void Set(IObjectResolver serviceResolver) => s_ControllerResolver = serviceResolver;
        public static T Get() => (T)s_ControllerResolver.Resolve();
    }
}