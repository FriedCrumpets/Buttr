// ReSharper disable StaticMemberInGenericType

namespace Buttr.Core {
    public static class Service<T> where T : IService {
        private static IObjectResolver s_ServiceResolver;
        internal static void Set(IObjectResolver serviceResolver) => s_ServiceResolver = serviceResolver;
        public static T Get() => (T)s_ServiceResolver.Resolve();
    }
}