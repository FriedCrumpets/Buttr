namespace Buttr.Core {
    public interface IService { }
}