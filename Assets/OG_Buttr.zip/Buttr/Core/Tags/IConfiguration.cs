namespace Buttr.Core {
    public interface IConfiguration { }
}