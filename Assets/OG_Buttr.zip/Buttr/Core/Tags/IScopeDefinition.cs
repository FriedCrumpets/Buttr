namespace Buttr.Core {
    public interface IScopeDefinition { }
}