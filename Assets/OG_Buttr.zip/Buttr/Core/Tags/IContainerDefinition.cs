namespace Buttr.Core {
    public interface IContainerDefinition { }
}