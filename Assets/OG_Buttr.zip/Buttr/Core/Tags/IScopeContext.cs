namespace Buttr.Core {
    public interface IScopeContext { }
}