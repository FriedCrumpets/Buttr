namespace Buttr.Core {
    public interface IController { }
}