using System;
using System.Collections.Generic;

namespace Buttr.Core {
    internal static class DIBuilderUtility {
        public static (List<object> dependencies, List<Type> remaining) GetDependencies(this Dictionary<Type, IObjectResolver> registry, List<Type> requirements) {
            var dependencies = new List<object>();
            var remaining = new List<Type>();
    
            foreach (var type in requirements) {
                if (registry.TryGetValue(type, out var value))
                    dependencies.Add(value.Resolve());
                else 
                    remaining.Add(type);
            }
            
            return (dependencies, remaining);
        }
    }
}