using System;
using System.Collections.Generic;
using UnityEngine;

namespace Buttr.Core {
    internal static class ServiceResolverUtilities {
        private static readonly List<Type> s_RemainingRequirements = new();
        
        public static bool TryValidate(this object[] foundDependencies, List<Type> requirements) {
            if (foundDependencies.Length != requirements.Count) return false;
            
            s_RemainingRequirements.Clear();
            s_RemainingRequirements.AddRange(requirements);
            for (var i = 0; i < foundDependencies.Length; i++) {
                var dependencyType = foundDependencies[i].GetType();
                var requiredType = requirements[i];

                if (requiredType.IsAssignableFrom(dependencyType)) {
                    s_RemainingRequirements.Remove(requiredType);
                }
                else {
                    Debug.LogWarning($"Dependency of type {dependencyType} does not satisfy required type {requiredType}.");
                }
            }

            return s_RemainingRequirements.Count == 0;
        }
    }
}