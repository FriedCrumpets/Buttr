namespace Buttr.Core {
    internal interface IContainerBuilder<TScope> {
        public TScope Build<TType>() where TType : TScope;
    }
}