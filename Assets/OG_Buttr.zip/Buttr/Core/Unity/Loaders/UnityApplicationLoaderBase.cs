#if UNITY_6000_0_OR_NEWER
using System.Threading;
using UnityEngine;

namespace Buttr.Core {
    public abstract class UnityApplicationLoaderBase : ScriptableObject {
        public abstract Awaitable LoadAsync(CancellationToken cancellationToken);
        public virtual Awaitable UnloadAsync() { return AwaitableUtility.CompletedTask; }
    }
}
#endif