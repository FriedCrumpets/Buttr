using System;

namespace Buttr.Core {
    public sealed class UnityApplicationCleanup : IDisposable {
        private readonly IDisposable m_Disposable;

        public UnityApplicationCleanup(IDisposable[] Disposables) {
            m_Disposable = new DisposableCollection(Disposables);
        }
        
        public void Dispose() {
            m_Disposable.Dispose();
        }
    }
}