using System;

namespace Buttr.Core {
    public sealed class UnityContainerBuilder : IContainerBuilder<IUnityApplication> {
        private readonly IServiceCollection m_Services = new ApplicationServiceCollection();
        private readonly IConfigurationCollection m_Configurations = new ApplicationConfigurationCollection();
        private readonly IControllerCollection m_Controllers = new ApplicationControllerCollection();
        private readonly IHiddenCollection m_Hidden = new ApplicationHiddenCollection();
        private readonly IRepositoryCollection m_Repositories = new ApplicationRepositoryCollection();
        private readonly IScopeCollection m_Scopes = new ApplicationScopeCollection();
        private readonly IContainerCollection m_Containers = new ApplicationContainerCollection();

        private IDisposable m_Disposable;

        public IServiceCollection Services { get { return m_Services; } }
        public IConfigurationCollection Configurations { get { return m_Configurations; } }
        public IControllerCollection Controllers { get { return m_Controllers; } }
        public IHiddenCollection Hidden { get { return m_Hidden; } }
        public IRepositoryCollection Repositories { get { return m_Repositories; } }
        public IScopeCollection Scopes { get { return m_Scopes; } }
        public IContainerCollection Containers { get { return m_Containers; } }
        
        public UnityApplicationCleanup Cleanup {
            set { m_Disposable = value; }
        }
        
        public IUnityApplication Build<T>() where T : IUnityApplication {
            m_Services.Resolve();
            m_Controllers.Resolve();
            m_Hidden.Resolve();
            m_Repositories.Resolve();
            m_Scopes.Resolve();
            
            var cleanup = m_Disposable ?? new DisposableCollection(new IDisposable[]{ m_Services, m_Controllers, m_Hidden, m_Repositories });

            return (T)Activator.CreateInstance(typeof(T), new object[] { cleanup });
        }
    }
}