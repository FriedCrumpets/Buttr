using System.Collections.Generic;
using UnityEngine;

namespace Buttr.Core {
    public static class Program {
        public static IUnityApplication Main() => Main(CMDArgs.Read());

        private static IUnityApplication Main(IDictionary<string, string> args) {
            var builder = new UnityContainerBuilder();

            Debug.Log("Built");
            
            return builder.Build<UnityApplication>();
        }
    }
}