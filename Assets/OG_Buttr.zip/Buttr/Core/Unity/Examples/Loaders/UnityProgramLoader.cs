using System.Threading;
using UnityEngine;

namespace Buttr.Core {
    [CreateAssetMenu(fileName = "ProgramLoader", menuName = "Buttr/Examples/Loaders/Program")]
    public sealed class UnityProgramLoader : UnityApplicationLoaderBase {
        private IUnityApplication m_Application;
        
        public override async Awaitable LoadAsync(CancellationToken cancellationToken) {
            m_Application = Program.Main();
            await m_Application.Run(cancellationToken);
        }

        public override Awaitable UnloadAsync() {
            m_Application.Quit();
            return AwaitableUtility.CompletedTask;
        }
    }
}