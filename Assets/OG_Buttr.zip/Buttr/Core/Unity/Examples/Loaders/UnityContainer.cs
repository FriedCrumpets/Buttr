using System.Threading;
using UnityEngine;

namespace Buttr.Core {
    [CreateAssetMenu(fileName = "UnityContainer", menuName = "Buttr/Examples/Loaders/Container", order = 0)]
    public sealed class UnityContainer : UnityApplicationLoaderBase {
        private IUnityApplication m_App;

        public override async Awaitable LoadAsync(CancellationToken cancellationToken) {
            var builder = new UnityContainerBuilder();

            m_App = builder.Build<UnityApplication>();
            
            await m_App.Run(cancellationToken);
        }

        public override Awaitable UnloadAsync() {
            m_App.Quit();
            return AwaitableUtility.CompletedTask;
        }
    }
}