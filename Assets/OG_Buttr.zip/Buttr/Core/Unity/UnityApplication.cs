#if UNITY_6000_0_OR_NEWER
using System;
using System.Threading;
using UnityEngine;

namespace Buttr.Core {
    public abstract class UnityApplication : IUnityApplication {
        protected UnityApplication(IDisposable cleanup) {}
        
        public abstract Awaitable Run(CancellationToken cancellationToken);

        public abstract void Quit();
    }
}
#endif