using System.Threading;
using UnityEngine;

namespace Buttr.Core {
    public interface IUnityApplication {
        Awaitable Run(CancellationToken cancellationToken);
        void Quit();
    }
}