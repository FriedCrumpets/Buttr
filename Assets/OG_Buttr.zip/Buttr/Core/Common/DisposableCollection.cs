using System;

namespace Buttr.Core {
    internal sealed class DisposableCollection : IDisposable {
        private readonly IDisposable[] m_Disposables;
        
        public DisposableCollection(IDisposable[] disposables) {
            m_Disposables = disposables;
        }

        public void Dispose() {
            foreach(var disposable in m_Disposables) disposable.Dispose();
        }
    }
}