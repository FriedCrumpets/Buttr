using System;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace Buttr.Core {
    internal static class ObjectFactory {
        internal static Func<object[], TConcrete> Create<TConcrete>(ConstructorInfo constructor) {
            var parametersParameter = Expression.Parameter(typeof(object[]), "args");

            var constructorParameters = constructor.GetParameters()
                .Select((param, index) =>
                    Expression.Convert(
                        Expression.ArrayIndex(parametersParameter, Expression.Constant(index)),
                        param.ParameterType))
                .ToArray<Expression>();

            var newExpression = Expression.New(constructor, constructorParameters);
            return Expression.Lambda<Func<object[], TConcrete>>(newExpression, parametersParameter).Compile();
        }
    }
}