namespace Buttr.Core {
    /// <summary>
    /// Specifically designed for application extension.
    /// Use to define containers of objects that exist outside the static registry, but can be accessed inside via Static Means 
    /// </summary>
    /// <remarks>
    /// Use this when developing containers for pockets of functionality that should not be injected into your main application.
    /// Fundamentally, If you're developing a package that you DO NOT want to share resolvers with the wider application your installing to then use this.
    ///
    /// Let's say I am developing a package for addressables. This would probably be useful in the static registry. So I wouldn't use a container.
    /// If I'm developing a package for Tweening. This is gameplay related, we may want this to be external to the static registry. So I would use a container.
    /// </remarks>
    public sealed class ApplicationContainer : IContainerResolver {
        private IResolver m_Resolver;
        
        public IConfigurable<IDIBuilder> DefineContainer<TContainerDefinition>() where TContainerDefinition : IContainerDefinition {
            var resolver = new ContainerResolver<TContainerDefinition>();
            m_Resolver = resolver;
            return resolver;
        }
        
        public void Resolve() {
            m_Resolver.Resolve();
        }
        
        public void Dispose() {
            m_Resolver.Dispose();
        }
    }
}