using System.Collections.Generic;

namespace Buttr.Core {
    /// <summary>
    /// Used to define multiple <see cref="ApplicationContainer"/>
    /// </summary>
    /// <remarks>
    /// For the most part this will likely not be widely used, but useful if a package your developing does multiple things and each container should not interact with each other.
    /// </remarks>
    public sealed class ApplicationContainerCollection : IContainerCollection {
        private readonly List<IResolver> m_Resolvers = new();
        
        public IConfigurable<IDIBuilder> DefineContainer<TContainerDefintion>() where TContainerDefintion : IContainerDefinition {
            var resolver = new ApplicationContainer();
            m_Resolvers.Add(resolver);
            return resolver.DefineContainer<TContainerDefintion>();
        }
        
        public void Resolve() {
            foreach(var resolver in m_Resolvers) resolver.Resolve();
        }
        
        public void Dispose() {
            foreach(var resolver in m_Resolvers) resolver.Dispose();
        }
    }
}