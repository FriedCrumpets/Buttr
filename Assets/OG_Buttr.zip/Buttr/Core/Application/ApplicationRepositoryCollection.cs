using System.Collections.Generic;

namespace Buttr.Core {
    /// <summary>
    /// Repositories remain hidden and are not available for static access
    /// All repositories are Singletons
    /// </summary>
    /// <remarks>
    /// Repositories talk directly to a database, data store or in the case of Unity your asset library.
    /// They shouldn't be used for anything other than CRUD operations.
    /// </remarks>
    public sealed class ApplicationRepositoryCollection : IRepositoryCollection {
        private readonly List<IResolver> m_Resolvers = new();

        public IConfigurable<TConcrete> AddRepository<TAbstract, TConcrete>() where TConcrete : TAbstract where TAbstract : IRepository {
            var resolver = new StaticRepositoryResolver<TAbstract, TConcrete>();
            m_Resolvers.Add(resolver);
            return resolver;
        }

        public void Resolve() {
            foreach(var resolver in m_Resolvers) resolver.Resolve();
        }

        public void Dispose() {
            foreach(var resolver in m_Resolvers) resolver.Dispose();
        }
    }
}