using System.Collections.Generic;

namespace Buttr.Core {
    /// <summary>
    /// Will resolve a container of objects to Scope { T } access point
    /// </summary>
    /// <remarks>
    /// Upon Defining a Scope it should be provided with relevant objects to resolve through its <see cref="IConfigurable{TConcrete}"/>
    /// </remarks>
    public sealed class ApplicationScopeCollection : IScopeCollection {
        private readonly List<IResolver> m_Resolvers = new();
        
        public IConfigurable<IDIBuilder> DefineScope<TScopeDefinition>() where TScopeDefinition : IScopeDefinition {
            var resolver = new ScopeResolver<TScopeDefinition>();
            m_Resolvers.Add(resolver);
            return resolver;
        }
        
        public void Resolve() {
            foreach(var resolver in m_Resolvers) resolver.Resolve();
        }
        
        public void Dispose() {
            foreach(var resolver in m_Resolvers) resolver.Dispose();
        }
    }
}