# Collections And Containers

We use the objects present here to build our registry of objects that are used for the static injection container and 
for static access. 

Fundamentally these objects should be used to build the application containers at the start of the applications runtime. 
Static application containers/collections should be the fundamental building blocks of your application and should be 
extended with DIContainers later in the application when necessary.

Having said that there are no rules here. They can be constructed and resolved at any time to extend the static registry, 
although it's advised to cache the reference for correct disposal when it's time.

### Collections
Collections are simply a collection of resolvers. The chosen collection will determine which static access point 
the object being resolved will be available from within the application.
- ApplicationConfigurationCollection -> Configuration < T >
  - A Configuration will always be a singleton
- ApplicationContainerCollection -> Container < T > 
  - < T > is of type IContainerDefinition. Container objects exist outside the static registry
- ApplicationControllerCollection -> Controller < T >
  - Controllers can be either Transient or Singleton
- ApplicationScopeCollection -> Scope < T >
  - < T > is of type IScopeDefinition. Scoped objects exist outside the static registry.
- ApplicationServiceCollection -> Service < T >
  - Services can be either Transient or Singleton

There are some nuances with the following

- ApplicationContainer
  - does not resolve the contained objects to the static registry
- ApplicationRepository
  - does not resolve the contained objects to a static accessor (no Repository< T >) 
- ApplicationHiddenCollection 
  - all objects resolved here will resolve to the static registry, but will not be statically accessible


    