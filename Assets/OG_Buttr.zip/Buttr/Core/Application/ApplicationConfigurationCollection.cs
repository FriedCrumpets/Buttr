using System.Collections.Generic;

namespace Buttr.Core {
    /// <summary>
    /// Will resolve objects to the Configuration { T } access point
    /// </summary>
    /// <remarks>
    /// Configurations were designed to be individual hard coded configurations that other objects require.
    /// They will always be resolved as singletons. It's advised that all configurations are immutable and serve as
    /// essential configurations for other resolving objects to look to for initialisation.
    ///
    /// If you prefer using ScriptableObjects for configuration, this is advised to be done using Addressables or Resources before handling any other resolvers.
    /// 
    /// If using addressables you can pre-warm ScriptableObjects by using a <see cref="UnityApplicationLoaderBase"/>
    /// Following a prewarm a <see cref="ApplicationConfigurationCollection"/> can be created and configurations added here.
    /// It should be noted that when doing this, for each configuration added ensure that .WithFactory(() => scriptableobjectreference)) // where scriptableobjectreference is the cached reference to the relevant ScriptableObject configuration
    ///
    /// Once loaded you could then resolve all further Collections for your application.
    /// </remarks>
    public sealed class ApplicationConfigurationCollection : IConfigurationCollection {
        private readonly List<IResolver> m_Resolvers = new();
        
        public IConfigurable<TConcrete> AddConfiguration<TAbstract, TConcrete>() where TConcrete : TAbstract where TAbstract : IConfiguration {
            var resolver = new StaticConfigurationResolver<TAbstract, TConcrete>();
            m_Resolvers.Add(resolver);
            return resolver;
        }

        public void Resolve() {
            foreach(var resolver in m_Resolvers) resolver.Resolve();
        }

        public void Dispose() {
            foreach(var resolver in m_Resolvers) resolver.Dispose();
        }
    }
}