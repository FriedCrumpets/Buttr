namespace Buttr.Core {
    public interface IContainerCollection : IResolver {
        IConfigurable<IDIBuilder> DefineContainer<TContainerDefintion>() where TContainerDefintion : IContainerDefinition;
    }
}