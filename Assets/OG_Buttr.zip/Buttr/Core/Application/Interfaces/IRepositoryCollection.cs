namespace Buttr.Core {
    public interface IRepositoryCollection : IResolver {
        public IConfigurable<TConcrete> AddRepository<TAbstract, TConcrete>()
            where TConcrete : TAbstract where TAbstract : IRepository;
    }
}