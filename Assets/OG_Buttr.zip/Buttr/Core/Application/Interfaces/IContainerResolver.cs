namespace Buttr.Core {
    public interface IContainerResolver : IResolver {
        IConfigurable<IDIBuilder> DefineContainer<TContainerDefinition>() where TContainerDefinition : IContainerDefinition;
    }
}