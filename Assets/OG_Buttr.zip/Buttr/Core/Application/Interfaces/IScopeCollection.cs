namespace Buttr.Core {
    public interface IScopeCollection : IResolver {
        IConfigurable<IDIBuilder> DefineScope<TScopeDefinition>() where TScopeDefinition : IScopeDefinition;
    }
}