namespace Buttr.Core {
    public interface IServiceCollection : IResolver {
        public IConfigurable<TConcrete> AddTransient<TAbstract, TConcrete>() where TConcrete : TAbstract where TAbstract : IService;
        public IConfigurable<TConcrete> AddSingleton<TAbstract, TConcrete>() where TConcrete : TAbstract where TAbstract : IService ;
    }
}