namespace Buttr.Core {
    public interface IConfigurationCollection : IResolver {
        public IConfigurable<TConcrete> AddConfiguration<TAbstract, TConcrete>() where TConcrete : TAbstract where TAbstract : IConfiguration; 
    }
}