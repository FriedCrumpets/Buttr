namespace Buttr.Core {
    public interface IHiddenCollection : IResolver {
        public IConfigurable<TConcrete> AddTransient<TAbstract, TConcrete>() where TConcrete : TAbstract; 
        public IConfigurable<TConcrete> AddSingleton<TAbstract, TConcrete>() where TConcrete : TAbstract; 
    }
}