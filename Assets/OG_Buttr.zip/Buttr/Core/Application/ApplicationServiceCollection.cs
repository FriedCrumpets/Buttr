using System.Collections.Generic;

namespace Buttr.Core {
    /// <summary>
    /// Will Resolve objects to the Service { T } access point
    /// </summary>
    /// <remarks>
    /// Controllers and Services hold no differentiation other than access point, this is more about design philosophy.
    ///
    /// A Transient is an object that will be resolved as a new object each time it is required in DI or Statically accessed
    /// A Singleton is an object that will be resolved once and further calls will receive the same object, both through DI or Statically accessed. 
    /// </remarks>
    public sealed class ApplicationServiceCollection : IServiceCollection {
        private readonly List<IResolver> m_Resolvers = new();
        
        public IConfigurable<TConcrete> AddTransient<TAbstract, TConcrete>() where TConcrete : TAbstract where TAbstract : IService {
            var resolver = new StaticServiceTransientResolver<TAbstract, TConcrete>();
            m_Resolvers.Add(resolver);
            return resolver;
        }
        
        public IConfigurable<TConcrete> AddSingleton<TAbstract, TConcrete>() where TConcrete : TAbstract where TAbstract : IService  {
            var resolver = new StaticServiceSingletonResolver<TAbstract, TConcrete>();
            m_Resolvers.Add(resolver);
            return resolver;
        }

        public void Resolve() {
            foreach(var resolver in m_Resolvers) resolver.Resolve();
        }

        public void Dispose() {
            foreach(var resolver in m_Resolvers) resolver.Dispose();
        }
    }
}