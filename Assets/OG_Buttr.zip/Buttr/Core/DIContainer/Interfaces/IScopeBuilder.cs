namespace Buttr.Core {
    public interface IScopeBuilder {
        IDIBuilder WithContext<TAbstractContext, TConcreteContext>(TConcreteContext context);
    }
}