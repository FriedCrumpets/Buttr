using System;

namespace Buttr.Core {
    public interface IDIBuilder<in TID> {
        Type Type { get; }
        
        IConfigurable<TConcrete> AddTransient<TConcrete>(TID id);
        IConfigurable<TConcrete> AddSingleton<TConcrete>(TID id);
        IDIContainer<TID> Build();
    }
    public interface IDIBuilder {
        IConfigurable<TConcrete> AddTransient<TAbstract, TConcrete>();
        IConfigurable<TConcrete> AddSingleton<TAbstract, TConcrete>();
        IDIContainer Build();
    }
}