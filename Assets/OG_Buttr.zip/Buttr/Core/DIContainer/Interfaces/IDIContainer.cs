using System;

namespace Buttr.Core {
    public interface IDIContainer<in TID> : IDisposable {
        Type Type { get; }

        TConcrete Get<TConcrete>(TID id);
    }
    public interface IDIContainer : IDisposable {
        TAbstract Get<TAbstract>();
    }
}