using System;
using System.Collections.Generic;

namespace Buttr.Core {
    /// <summary>
    /// Created from a <see cref="DIBuilder{TID}"/>. A container to retrieve objects from.
    /// </summary>
    /// <remarks>
    /// The container should be cached and kept for use until disposal. It's advised to dispose of containers when finished.
    /// </remarks>
    /// <typeparam name="TID">The ID for which behaviours are to be identified</typeparam>
    public class DIContainer<TID> : IDIContainer<TID> {
        private readonly Dictionary<TID, IObjectResolver> m_Registry;
        
        internal DIContainer(Dictionary<TID, IObjectResolver> registry) {
            m_Registry = registry;
        }
        
        public Type Type => typeof(TID);
        
        public TConcrete Get<TConcrete>(TID id) {
            if (m_Registry.TryGetValue(id, out var resolver))
                return (TConcrete)resolver.Resolve();

            return default;
        }
        
        public void Dispose() {
            foreach (var resolver in m_Registry.Values) {
                if (resolver.Resolve() is IDisposable disposable) {
                    disposable.Dispose();
                }
            }
            
            m_Registry.Clear();
        }
    }
    
    /// <summary>
    /// Created from a <see cref="DIBuilder"/>. A container to retrieve objects from.
    /// </summary>
    /// <remarks>
    /// The container should be cached and kept for use until disposal. It's advised to dispose of containers when finished.
    /// </remarks>
    internal sealed class DIContainer : IDIContainer {
        private readonly Dictionary<Type, IObjectResolver> m_Registry;

        internal DIContainer(Dictionary<Type, IObjectResolver> registry) {
            m_Registry = registry;
        }

        public TAbstract Get<TAbstract>() {
            if (m_Registry.TryGetValue(typeof(TAbstract), out var resolver))
                return (TAbstract)resolver.Resolve();

            return default;
        }

        public void Dispose() {
            foreach (var resolver in m_Registry.Values) {
                if (resolver.Resolve() is IDisposable disposable) disposable.Dispose();
            }

            m_Registry.Clear();
        }
    }
}