namespace Buttr.Core {
    internal sealed class ScopeBuilder : IScopeBuilder {
        private readonly IDIBuilder m_Builder;

        public ScopeBuilder(IDIBuilder builder) {
            m_Builder = builder;
        }
        
        public IDIBuilder WithContext<TAbstractContext, TConcreteContext>(TConcreteContext context) {
            m_Builder.AddSingleton<TAbstractContext, TConcreteContext>()
                .WithFactory(() => context);
            return m_Builder;
        }
    }
}